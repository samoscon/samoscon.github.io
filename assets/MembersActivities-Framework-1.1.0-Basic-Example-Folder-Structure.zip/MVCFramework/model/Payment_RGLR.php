<?php
/**
 * Payment_RGLR.php
 *
 * @package model
 * @version 1.0
 * @copyright (c) 2025, Dirk Van Meirvenne
 * @author Dirk Van Meirvenne <van.meirvenne.dirk at gmail.com>
 */
namespace model;

/**
 * Represents a normal Payment (of an order or a prepaid amount).
 * 
 * Implementation follows the design pattern 'Builder'
 *
 * @author Dirk Van Meirvenne <van.meirvenne.dirk at gmail.com>
 */
class Payment_RGLR extends \membersactivities\model\subscriptions\PaymentTypeImplementation {
//    #[\Override]
//    public function statusReceived(\model\Payment $payment, string $token, string $status): void {
//        // Put here your code if special things needs to be done when a payment status is received. E.g.
//        if($status === 'paid'){
//            $subscription = $this->getSubscription($payment);
//            /*
//             * Create one ticket for each ordered ticket.
//             *
//             * A subscription can contain multiple tickets because
//             * subscription.quantity represents the number of tickets ordered.
//             */
//            foreach (\model\Subscription::findAll(
//                "WHERE payment_id = " . $payment->getId()
//            ) as $subscription) {
//
//                for ($i = 0; $i < $subscription->quantity; $i++) {
//
//                    \model\Ticket::insert([
//                        'description'    => 'Ticket',
//                        'classification' => 'RGLR',
//                        'subscription_id' => $subscription->getId(),
//                        'token'          => bin2hex(random_bytes(32))
//                    ]);
//                }
//            }
//            // Create your wallet tickets          
//            if(_WALLETISSUERID) {
//                $this->initiateGoogleWalletTickets($payment, $subscription->costitem->activity);
//            }
//            // Send an email to the member confirming his tickets have been paid
//            $orderedTickets = $this->getOrderedTicketsText($payment);
//            $download = $this->getDownloadText($payment, $token, $subscription->costitem->activity);
//            
//$body =<<<_MAIL_
//$orderedTickets
//$download
//<br><br>
//Kind regards,<br>
//Brussels Muzieque
//_MAIL_;
//            \controllerframework\mail\Mailer::sendMail("Tickets {$subscription->costitem->activity->description}", $body, _MAILTO, $payment->member->email);               
//            $payment->update(array("source" => 'mollie tickets sent', 'status' => 'paid'));
//        }
//    }
    #[\Override]
    public function statusReceived(
        \model\Payment $payment,
        string $token,
        string $status
    ): void {

        if ($status !== 'paid') {
            $payment->update([
                'status' => $status
            ]);
            return;
        }

        $reg = \controllerframework\registry\Registry::instance();
        $db = $reg->getDb();

        try {
            $db->beginTransaction();

            /*
             * Lock the payment row.
             *
             * This is important because Mollie may send the same payment
             * notification more than once. A second callback has to wait
             * until the first transaction has completed.
             */
            $stmt = $db->prepare(
                "SELECT status
                 FROM payment
                 WHERE id = ?
                 FOR UPDATE"
            );

            $stmt->execute([
                $payment->getId()
            ]);

            $paymentRow = $stmt->fetch();

            if (!is_array($paymentRow)) {
                throw new \Exception(
                    "Payment with id {$payment->getId()} does not exist."
                );
            }

            /*
             * The payment may already have been processed by an earlier
             * callback. In that case there is nothing more to do.
             */
            if ($paymentRow['status'] === 'paid') {
                $db->rollBack();
                return;
            }

            /*
             * Create one ticket for every ticket ordered in every
             * subscription belonging to this payment.
             */
            $subscriptions = \model\Subscription::findAll(
                "WHERE payment_id = " . (int) $payment->getId()
            );

            foreach ($subscriptions as $subscription) {

                $seats = explode(';', $subscription->remark);
                
                for ($i = 0; $i < $subscription->quantity; $i++) {
                    
                    \model\Ticket::insert([
                        'description'     => 'Ticket',
                        'classification'  => 'RGLR',
                        'subscription_id' => $subscription->getId(),
                        'token'           => bin2hex(random_bytes(32)),
                        'seat'             => $seats[$i]
                    ]);
                }
            }

            /*
             * Mark the payment as processed.
             *
             * This happens inside the same transaction as the ticket
             * creation. Therefore the payment can only become 'paid'
             * when all tickets have been created successfully.
             */
            $payment->update([
                'source' => 'mollie tickets sent',
                'status' => 'paid'
            ]);

            /*
             * Everything succeeded.
             */
            $db->commit();

        } catch (\Throwable $e) {

            /*
             * No tickets and no payment status change survive a failure.
             */
            if ($db->inTransaction()) {
                $db->rollBack();
            }

            throw $e;
        }


        /*
         * Everything below is deliberately outside the transaction.
         *
         * Sending mail or creating Google Wallet tickets can take time
         * and should not keep the payment database row locked.
         */

        $subscription = $this->getSubscription($payment);

        // Create wallet tickets
        if (_WALLETISSUERID) {
            $this->initiateGoogleWalletTickets(
                $payment,
                $subscription->costitem->activity
            );
        }

        // Send an email to the member confirming his tickets have been paid
        $orderedTickets = $this->getOrderedTicketsText($payment);

        $download = $this->getDownloadText(
            $payment,
            $token,
            $subscription->costitem->activity
        );

    $body = <<< _MAIL_
$orderedTickets
$download
<br><br>
Kind regards,<br>
Brussels Muzieque
_MAIL_;

        \controllerframework\mail\Mailer::sendMail(
            "Tickets {$subscription->costitem->activity->description}",
            $body,
            _MAILTO,
            $payment->member->email
        );
    }
    
    public function getOrderedTicketsText(\model\Payment $payment): string {
            $subscriptions = '<ul class="list-inline">';
            $total = 0;
            foreach (\model\Subscription::findAll("WHERE payment_id = ".$payment->getId()) as $subscription) {
                $subscriptions .= '<li>'.$subscription->costitem->description.' ('.$subscription->costitem->price.' EUR) * '.
                        $subscription->quantity.' = '.$subscription->quantity*$subscription->costitem->price.'.00 EUR</li>';
                $total += $subscription->quantity*$subscription->costitem->price;
            }
            $subscriptions .= '</ul><p><b>Total: </b>'.$total.'.00 EUR</p><br>';
            if($total != $payment->amount){
                $subscriptions .= '<i>Cost reduction: '. $payment->amount - $total . '.00 EUR</i><br>'.
                        '<b>Amount paid: '.$payment->amount.' EUR</b>';
            }
            
            $whenandwhere = $this->getWhenandwhere($subscription);
            return '<h3>Tickets '.$subscription->costitem->activity->description.'</h3><br>'
                    .'<br>'.$whenandwhere.'<br><b>Your ordered tickets:</b><br>'
                    .$subscriptions.'<br><br>';            
    }
    
    public function getWhenandwhere(\model\Subscription $subscription): string {
        $activity = $subscription->costitem->activity;
        if(!$activity->isComposite()) {
            return "<p><b>When:</b> " . date('d/m/Y', strtotime($activity->date)) . " (" . substr($activity->start,0,5) . " - " . substr($activity->end,0,5) . ")</p><br>
                            <p><b>Where:</b> " . $activity->location . "</p><br>";
        } else {
            return str_replace("&nbsp;", '',strip_tags($activity->longdescription)) . "<br>";
        }                
    }
    
    public function getDownloadText(\model\Payment $payment, string $token, \membersactivities\model\activities\Activity $activity): string {
        if(!$activity->isComposite()) {
          if (_WALLETISSUERID) {
            $googleWalletToken = (new \model\GoogleWalletTicket())->createJWT($payment->getId());
            $imgsrc = _ASSETDIR.'enUS_add_to_google_wallet_wallet-button.png';
            return 'You can <a href="'._APPDIR.'pdfTickets?id='.($payment->getId()).'&access_token='.$token.'">'
                    . 'download your tickets in pdf format'
                    . '</a>'
                    . ' or <br><br>'
                    . '<a href="'.$googleWalletToken.'"><img src="'.$imgsrc.'" style="width:192px;height:48px;" alt="Download your tickets in Google Wallet"/></a>'
                    ;
          } else {
            return 'You can <a href="'._APPDIR.'pdfTickets?id='.($payment->getId()).'&access_token='.$token.'">'
                    . 'download your tickets in pdf format'
                    . '</a> here.'
                    ;
          }
        } else {
            return 'Your tickets for the individual concerts, will be sent to you 1 week before the event.';
        }                
    }
}
