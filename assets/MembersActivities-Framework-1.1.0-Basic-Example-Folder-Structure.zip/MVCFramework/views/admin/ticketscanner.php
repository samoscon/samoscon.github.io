<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"
    >

    <title>Ticket Scanner</title>
    

    <style>

        * {
            box-sizing: border-box;
        }

        html,
        body {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            background: #111;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        #scanner {
            width: 100%;
            max-width: 500px;
            min-height: 100%;
            background: #111;
            color: white;
            display: flex;
            flex-direction: column;
        }

        #header {
            padding: 15px;
            text-align: center;
        }

        #header h1 {
            margin: 0;
            font-size: 22px;
        }

        #activity {
            margin-top: 5px;
            font-size: 16px;
        }

        #reader {
            width: 100%;
            flex: 1;
        }

        #result {
            min-height: 170px;
            padding: 20px;
            text-align: center;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        #resultIcon {
            font-size: 65px;
            line-height: 1;
        }

        #resultMessage {
            margin-top: 10px;
            font-size: 28px;
            font-weight: bold;
        }

        #resultDetails {
            margin-top: 8px;
            font-size: 16px;
        }

        #counter {
            padding: 12px;
            text-align: center;
            font-size: 15px;
            background: #222;
        }

        .valid {
            background: #087f23;
        }

        .invalid {
            background: #a50000;
        }

        .waiting {
            background: #111;
        }

    </style>

</head>

<body>

<div id="scanner">

    <div id="header">

        <h1>🎫 <?=_MAILFROMNAME?></h1>

        <div id="activity">
            Ticket Scanner
        </div>
        <p>
            Activity:
            <strong><?=htmlspecialchars($request->get('activity')->description);?></strong>
        </p>    

    </div>

    <div id="reader"></div>

    <div id="result" class="waiting">

        <div id="resultIcon">
            📷
        </div>

        <div id="resultMessage">
            Scan ticket
        </div>

        <div id="resultDetails">
            Hold the QR code in front of the camera
        </div>

    </div>

    <div id="counter">
        Scanned: <span id="scanCount">0</span>
    </div>

</div>


<?php echo'<script src="' . _APPDIR . 'MVCFramework/views/includes/js/html5-qrcode.min.js"></script>' ?>

<script>

let scanCount = 0;
let processing = false;


/*
 * Audio
 *
 * We create the sounds with Web Audio instead of requiring
 * separate sound files.
 */
const audioContext = new (
    window.AudioContext ||
    window.webkitAudioContext
)();


function beep(frequency, duration) {

    const oscillator = audioContext.createOscillator();
    const gain = audioContext.createGain();

    oscillator.frequency.value = frequency;

    oscillator.connect(gain);
    gain.connect(audioContext.destination);

    gain.gain.setValueAtTime(0.2, audioContext.currentTime);

    oscillator.start();

    oscillator.stop(
        audioContext.currentTime + duration
    );
}


/*
 * Valid ticket
 */
function successFeedback() {

    navigator.vibrate?.(100);

    beep(880, 0.12);

}


/*
 * Invalid ticket
 */
function errorFeedback() {

    navigator.vibrate?.([
        150,
        100,
        150
    ]);

    beep(220, 0.25);

}


/*
 * Display result
 */
function showResult(
    valid,
    message,
    details = ''
) {

    const result =
        document.getElementById('result');

    const icon =
        document.getElementById('resultIcon');

    const messageElement =
        document.getElementById('resultMessage');

    const detailsElement =
        document.getElementById('resultDetails');


    result.className =
        valid ? 'valid' : 'invalid';

    icon.textContent =
        valid ? '✓' : '✕';

    messageElement.textContent =
        message;

    detailsElement.textContent =
        details;

    if (valid) {
        successFeedback();
    } else {
        errorFeedback();
    }
}


/*
 * Return to scanner screen.
 */
function resetResult() {

    const result =
        document.getElementById('result');

    result.className = 'waiting';

    document.getElementById(
        'resultIcon'
    ).textContent = '📷';

    document.getElementById(
        'resultMessage'
    ).textContent = 'Scan ticket';

    document.getElementById(
        'resultDetails'
    ).textContent =
        'Hold the QR code in front of the camera';

}


/*
 * Send token to the server.
 */
async function validateTicket(token) {

    try {

        const response = await fetch(
            '/validateTicket',
            {
                method: 'POST',

                headers: {
                    'Content-Type':
                        'application/x-www-form-urlencoded'
                },

                body: new URLSearchParams({
                    token: token,
                    id: '<?=$request->get('activity')->getId();?>'
                })
            }
        );


        if (!response.ok) {
            throw new Error(
                'HTTP ' + response.status
            );
        }


        const data =
            await response.json();


        /*
         * AjaxRenderComponent returns:
         *
         * [
         *     {
         *         valid: true,
         *         message: "...",
         *         ...
         *     }
         * ]
         */

        const result =
            data[0];


        if (!result) {
            throw new Error(
                'Invalid server response'
            );
        }


        if (result.valid) {

            scanCount++;

            document.getElementById(
                'scanCount'
            ).textContent = scanCount;


            showResult(
                true,
                result.message,
                result.ticketType
                    ? 'Type: ' + result.ticketType
                    : ''
            );

        } else {

            showResult(
                false,
                result.message,
                result.ticketId
                    ? 'Ticket #' + result.ticketId
                    : ''
            );

        }


        /*
         * Give the operator time to see the result
         * before allowing another scan.
         */
        setTimeout(() => {

            processing = false;
            resetResult();

        }, 1800);


    } catch (error) {

        console.error(error);

        showResult(
            false,
            'Scanner error',
            'Could not contact the server'
        );


        setTimeout(() => {

            processing = false;
            resetResult();

        }, 2500);

    }

}


/*
 * QR-code successfully decoded.
 */
function onScanSuccess(
    decodedText,
    decodedResult
) {

    /*
     * Prevent multiple callbacks while the same
     * QR-code remains in front of the camera.
     */
    if (processing) {
        return;
    }

    processing = true;

    /*
     * The QR code currently contains only the token.
     */
    const token =
        decodedText.trim();

    /*
     * Stop scanning while the result is displayed.
     */
    html5QrcodeScanner.pause(
        true
    );

    validateTicket(token)
        .finally(() => {

            /*
             * Resume camera scanning.
             */
            try {
                html5QrcodeScanner.resume();
            } catch (e) {
                console.error(e);
            }

        });
}


/*
 * QR-code scanner.
 */
const html5QrcodeScanner =
    new Html5QrcodeScanner(
        'reader',
        {
            fps: 10,

            qrbox: {
                width: 250,
                height: 250
            },

            rememberLastUsedCamera: true
        },
        false
    );


html5QrcodeScanner.render(
    onScanSuccess,
    (errorMessage) => {
        /*
         * QR scanning continuously generates
         * "not found" messages. We deliberately
         * don't display them.
         */
    }
);

</script>

</body>
</html>