<?php 
    $activity = $request->get('activity');
    $participants = $request->get('participants');
?>
<!DOCTYPE html>
<html>
    <head>
        <?php include 'MVCFramework/views/includes/head.php'; ?>
        <title><?=$activity->description?></title>
    </head>
    <body>
        <div class="container-fluid p-3 bg-secondary text-light">
            <div class="d-flex w-100 justify-content-between">
                <a class="btn btn-dark btn-sm" href="<?=$request->get('returnpath')?>" role="button" style="max-height: 32px"><i class="fa fa-calendar"></i></a>
                <p class="text-center"><b><?=$activity->description?></b></p>
            </div>
        </div>
        <div class="container mt-3">                
            <div class="row">
                <div class="col-lg-9 mt-5">
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h3>Abonnementen voor <?=$activity->description?></h3>

                        </div>
                        <div class="card-body">
                        <form name="generateTicketsOverview" method="POST">                   
                            <input type="hidden"
                                   name="csrf_token"
                                   value="<?= htmlspecialchars(
                                       $request->get('csrf_token'),
                                       ENT_QUOTES,
                                       'UTF-8'
                                   ) ?>">
                            <ul>
                            <?php foreach ($participants as $participant) { ?>
                               
                                <li><?= $participant->name?> - - - <?= $participant->costitem?></li>
                            <?php } ?>
                            </ul>
                            <!-- Submit button -->
                            <button type="submit" class="btn btn-dark btn-block m-5">Generate</button>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>                
    </body>
</html>