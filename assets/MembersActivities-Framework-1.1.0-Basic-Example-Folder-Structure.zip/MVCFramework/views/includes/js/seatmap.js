$(document).ready(function(){

    var $result = $('#resultCart');
    var $activityid = $('#activityid').val();

    getReservedSeats();

    /*
     * Initially the seatmap is visible and the order section is hidden.
     */
    $('#seatmapSection').show();
    $('#orderSection').hide();


    function getReservedSeats() {

        $.ajax({
            type: "get",
            async: true,
            dataType: 'json',
            url: "getReservedSeats",
            data: {'id': $activityid},

            success: setupSeatChart,

            error: function(xhr){
                alert(
                    "An error occured in getReservedSeats " +
                    xhr.status + " " +
                    xhr.statusText
                );
            }
        });
    }


    function resizeSeatMap() {

        var map = document.querySelector('.sc-map');
        var container = document.querySelector('.seatchart');

        if (!map || !container) {
            return;
        }

        // Reset zoom before measuring
        map.style.zoom = '1';

        var availableWidth = container.clientWidth - 10;
        var mapWidth = map.offsetWidth;

        // The map already fits
        if (mapWidth <= availableWidth) {
            return;
        }

        // Calculate required scale
        var scale = availableWidth / mapWidth;

        // Small safety margin
        scale *= 0.95;

        map.style.zoom = scale;
    }


    function setupSeatChart(SeatChart) {

        var element = document.getElementById('container');

        var options = {

            cart: {
                /*
                 * This is the ONE button that will be used.
                 */
                submitLabel: 'Reserve your seat(s)',
                visible: true
            },

            legendVisible: {
                legendVisible: true
            },

            map: {

                rows: 12,
                columns: 20,

                seatTypes: {

                    default: {
                        label: 'Economy',
                        cssClass: 'economy',
                        price: SeatChart[0]["map"][1]["priceDefault"]
                    },

                    first: {
                        label: 'First Class',
                        cssClass: 'first-class',
                        price: SeatChart[0]["map"][2]["priceFirst"],

                        seatRows: [0, 1, 2, 7],

                        seats: [
                            {row: 3, col: 5},
                            {row: 3, col: 6},
                            {row: 3, col: 7},
                            {row: 3, col: 8},
                            {row: 3, col: 9},
                            {row: 3, col: 10},
                            {row: 3, col: 11},
                            {row: 3, col: 12},
                            {row: 3, col: 13},
                            {row: 3, col: 14}
                        ]
                    },

                    reduced: {
                        label: 'Reduced',
                        cssClass: 'reduced',
                        price: SeatChart[0]["map"][3]["priceReduced"],
                        seatRows: [9, 10, 11]
                    }
                },

                disabledSeats: [
                    {row: 0, col: 0},
                    {row: 0, col: 19},
                    {row: 0, col: 1},
                    {row: 0, col: 18},
                    {row: 1, col: 0},
                    {row: 1, col: 19}
                ],

                reservedSeats: SeatChart[0]["map"][0]["reservedSeats"],

                rowSpacers: [3, 7],
                columnSpacers: [5, 15]
            }
        };

        var priceDefault = Number(SeatChart[0]["map"][1]["priceDefault"]);
        var priceFirst = Number(SeatChart[0]["map"][2]["priceFirst"]);
        var priceReduced = Number(SeatChart[0]["map"][3]["priceReduced"]);

        var sc = new Seatchart(element, options);


        /*
         * Resize after Seatchart has rendered.
         */
        setTimeout(resizeSeatMap, 100);
        setTimeout(resizeSeatMap, 300);


        /*
         * This is the existing Seatchart submit event.
         *
         * It is triggered when the user clicks
         * "Reserve your seat(s)" in the Seatchart cart.
         */
        sc.addEventListener('submit', function handleSubmit(e) {

            /*
             * Do not continue when the cart is empty.
             */
            if (!e.cart || e.cart.length === 0) {
                alert('Please reserve at least one seat.');
                return;
            }

            
            /*
             * Update total
             */
            $result.text(e.total);
            $('#total').val(e.total);


            /*
             * Build the reserved seats section.
             */
            var html = '<div class="col-12">';

            html += '<div class="d-flex align-items-center justify-content-between">';

            html += '<div>';
            html += '<b>Your reserved seats</b>';
            html += '</div>';

            html += '<button ';
            html += 'type="button" ';
            html += 'id="changeReservedSeatsButton" ';
            html += 'class="btn btn-dark btn-sm">';
            html += 'Change your reserved seat(s)';
            html += '</button>';

            html += '</div>';

            html += '<ul class="mt-2">';


            var x = 0;
            var firstSeats = '';

            var y = 0;
            var defaultSeats = '';

            var z = 0;
            var reducedSeats = '';


            for (var i in e.cart) {

                var seat = e.cart[i];

//                html += '<li>';
                var seatPrice = 0;
                var seatType = seat.type;

                if (seat.type === 'first') {
                    seatType = 'First Class';
                    seatPrice = priceFirst;
                }

                if (seat.type === 'default') {
                    seatType = 'Economy';
                    seatPrice = priceDefault;
                }

                if (seat.type === 'reduced') {
                    seatType = 'Reduced';
                    seatPrice = priceReduced;
                }

                html += '<li>';
                html += 'Seat: ' + seat.label +
                        ' - ' + seatType +
                        ' (€' + seatPrice.toFixed(2) + ')';

                html += '<input ';
                html += 'type="hidden" ';
                html += 'name="seat' + i + '" ';
                html += 'value=' + JSON.stringify(seat.index);
                html += '>';

                html += '</li>';


                if (seat.type === 'first') {

                    x++;

                    firstSeats +=
                        JSON.stringify(seat.index) + ';';
                }


                if (seat.type === 'default') {

                    y++;

                    defaultSeats +=
                        JSON.stringify(seat.index) + ';';
                }


                if (seat.type === 'reduced') {

                    z++;

                    reducedSeats +=
                        JSON.stringify(seat.index) + ';';
                }
            }


            html += '</ul>';

            html += '<p>';
            html += '<b>';
            html += 'Complete your order and as soon as we have received ';
            html += 'your payment, we will confirm your tickets.';
            html += '</b>';
            html += '</p>';

            html += '</div>';


            /*
             * Update quantities.
             */
            $('#first').val(x);
            $('#default').val(y);
            $('#reduced').val(z);

            $('#firstSeats').val(firstSeats);
            $('#defaultSeats').val(defaultSeats);
            $('#reducedSeats').val(reducedSeats);


            /*
             * Put the selected seats into the order section.
             */
            $('#yourReservedseats').html(html);


            /*
             * The seatmap has now done its job.
             *
             * Hide seatmap.
             * Show order section.
             */
            $('#seatmapSection').hide();
            $('#orderSection').show();


            /*
             * Scroll to the order section.
             */
            $('#orderSection')[0].scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });


            /*
             * Attach the "Change your reserved seat(s)" button.
             *
             * We attach it here because this button is created
             * dynamically above.
             */
            $('#changeReservedSeatsButton').on('click', function(){

                $('#orderSection').hide();
                $('#seatmapSection').show();


                /*
                 * Give the browser a moment to display the seatmap
                 * before recalculating its size.
                 */
                setTimeout(function(){
                    resizeSeatMap();
                }, 100);


                /*
                 * Scroll back to the seatmap.
                 */
                $('#seatmapSection')[0].scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });

            });


            sendCart(e.cart);

        });


    }


    function sendCart(cart) {

        window.location.href = "#name";

    }


    /*
     * Resize seatmap when screen orientation / size changes.
     */
    window.addEventListener('resize', function () {

        setTimeout(resizeSeatMap, 100);

    });

});