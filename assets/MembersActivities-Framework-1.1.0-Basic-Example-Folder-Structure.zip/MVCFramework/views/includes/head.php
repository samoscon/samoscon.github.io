<?php
ini_set('display_errors', FALSE);

echo '
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta charset="UTF-8">

<link rel="manifest" href="' . _APPDIR . 'assets/manifest.webmanifest">

<meta name="theme-color" content="#ffffff">
<meta name="mobile-web-app-capable" content="yes">

<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="Brussels Muzieque Ticketing">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="apple-touch-icon" href="' . _APPDIR . 'assets/apple-touch-icon.png">
<link rel="icon" sizes="45x45" href="' . _APPDIR . 'assets/apple-touch-icon.png">

<style>
    .ff {
        font-family: veranda, sans-serif;
        font-size: 0.875em;
        color: rgba(33, 37, 41, 0.75) !important;
    }
</style>
';

echo '
<script>
if ("serviceWorker" in navigator) {
    window.addEventListener("load", function () {
        navigator.serviceWorker.register("' . _APPDIR . 'service-worker.js")
            .then(function (registration) {
                console.log("Service Worker registered:", registration.scope);
            })
            .catch(function (error) {
                console.error("Service Worker registration failed:", error);
            });
    });
}
</script>
';