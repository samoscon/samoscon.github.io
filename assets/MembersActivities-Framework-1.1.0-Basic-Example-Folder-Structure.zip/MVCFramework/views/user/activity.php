<?php
    $activity = $request->get('activity');
    $member = $request->get('member') ?? '';
    $hasSeatmap = (bool) $request->get('seatmap');
?>
<!DOCTYPE html>
<html>
    <head>
        <?php include 'MVCFramework/views/includes/head.php'; ?>
        <title><?=APP?> Ticketing</title>

        <link rel="stylesheet" href="MVCFramework/views/includes/css/seatchart.css?v=6">
        <link rel="stylesheet" href="MVCFramework/views/includes/css/seatmap.css?v=13">

        <style>
            /*
             * Seatmap / order visibility
             */
            <?php if ($hasSeatmap) { ?>
            #seatmapSection {
                display: block;
            }

            #orderSection {
                display: none;
            }
            <?php } ?>
        </style>
    </head>

    <body>

        <input type="hidden" id="activityid" value="<?=$activity->getId()?>">

        <div class="container-fluid p-3 bg-white text-black-50">
            <div class="d-flex w-100 justify-content-between">
                <img src="<?=_LOGO?>" alt="Logo missing" width="35%"> 
                <p class="text-center"><b>Ticketing system</b></p>
                <p> </p>
            </div>
        </div>

        <div class="container mt-3">

            <h1 class="text-primary">
                <?="{$activity->description}"?>
            </h1>

            <div><?=$activity->longdescription?></div>
            <br>

            <b>When: </b><?=date('d/m/Y', strtotime($activity->date))?>

            <?php $start = $activity->start;?>
            <?=($start <> "00:00" && $start) ? " ({$start} -" : ""?>

            <?php $end = $activity->end;?>
            <?=($end <> "00:00" && $end) ? " {$end})" : ""?>
            <br>

            <br>
            <b>Where: </b>
            <?=$activity->location ?? 'Info volgt'?>
            <br>

            <?php if(_MINLEVELTOLOGIN !== 'A') {?>    
                <br>
                <b>Member: </b>
                <?=$member->name?>
                <br>
            <?php } ?>


            <?php if ($hasSeatmap) { ?>

                <!-- ===================================================== -->
                <!-- SEATMAP SECTION                                      -->
                <!-- ===================================================== -->

                <div id="seatmapSection">

                    <div id="container" class="seatchart mt-3"></div>

                </div>

            <?php } ?>


            <!-- ========================================================= -->
            <!-- ORDER SECTION                                            -->
            <!-- ========================================================= -->

            <div id="orderSection">

                <form method="POST">

                    <input type="hidden"
                           name="csrf_token"
                           value="<?= htmlspecialchars(
                               $request->get('csrf_token'),
                               ENT_QUOTES,
                               'UTF-8'
                           ) ?>">

                    <div class="card mt-5" style="width: 98%;">

                        <?php if ($hasSeatmap) { ?>

                            <div id="yourReservedseats" class="row m-3">

                                <div class="col-12 d-flex align-items-center justify-content-between">

                                    <div>
                                        <b>Your reserved seats</b>
                                    </div>

                                    <button
                                        type="button"
                                        id="changeReservedSeatsButton"
                                        class="btn btn-outline-dark btn-sm">
                                        Change your reserved seat(s)
                                    </button>

                                </div>

                            </div>

                        <?php } ?>


                        <div class="row m-3">

                            <?php
                            if($activity->costitems){

                                $i = 1;

                                foreach ($activity->costitems as $costitem) {
                            ?>

                                <div class="row mt-3" <?= $hasSeatmap ? 'style="display:none;"' : '' ?>>

                                    <div class="col-lg-3">

                                        <b>
                                            <label
                                                class="form-label"
                                                for="<?= $hasSeatmap
                                                    ? $costitem->description
                                                    : 'qty_'.$i
                                                ?>">
                                                <?=$costitem->descriptionWithPrice?>:
                                            </label>
                                        </b>

                                    </div>

                                    <div class="col-lg-2">

                                    <input type="number"
                                           min="0"
                                           max="99"
                                           value=""
                                           <?=$hasSeatmap ? 'readonly' : ''?>
                                           id="<?= $hasSeatmap ? $costitem->description : 'qty_'.$i ?>"
                                           name="<?=$costitem->getId()?>"
                                           class="qty form-control"
                                           <?=(!$hasSeatmap && $i === 1) ? 'autofocus' : ''?> />

                                    </div>

                                    <div class="col-lg-7">

                                        <input
                                            type="hidden"
                                            id="<?=$costitem->description.'Seats'?>"
                                            name="<?=$costitem->getId().'Seats'?>"
                                        >

                                        <input
                                            type="hidden"
                                            id="<?='price_'.$i?>"
                                            value="<?=$costitem->price?>"
                                        >

                                    </div>

                                </div>

                            <?php
                                    $i++;
                                }
                            }
                            ?>

                            <input
                                type="hidden"
                                id="numberOfCostitems"
                                value="<?=($i - 1)?>"
                            >

                        </div>


                        <?php if(_MINLEVELTOLOGIN === 'A') {?>

                            <div class="row m-3">

                                <div class="col-lg-3">
                                    <label for="name">
                                        <b>Name: </b>
                                    </label>
                                </div>

                                <div class="col-lg-9">

                                    <input
                                        type="text"
                                        placeholder="First and last name"
                                        size="35"
                                        required
                                        id="name"
                                        name="name"
                                        value="<?=$request->get('name')?>"
                                        class="form-control"
                                    >

                                </div>

                            </div>

                            <?php if ($request->get('nameIsEmpty')) { ?>
                                <div class="row m-3 text-danger">
                                    * Provide a name
                                </div>
                            <?php } ?>


                            <div class="row m-3">

                                <div class="col-lg-3">
                                    <label for="email">
                                        <b>Email: </b>
                                    </label>
                                </div>

                                <div class="col-lg-9">

                                    <input
                                        type="text"
                                        placeholder="Valid mailaddress"
                                        size="35"
                                        required
                                        id="email"
                                        name="email"
                                        value="<?=$request->get('email')?>"
                                        class="form-control"
                                    >

                                </div>

                            </div>

                            <?php if ($request->get('emailIsEmpty')) { ?>
                                <div class="row m-3 text-danger">
                                    * Provide a valid email address
                                </div>
                            <?php } ?>

                        <?php } ?>


                        <div class="row m-3">

                            <h3 class="text-primary">
                                Total to pay:

                                <span id="<?=$hasSeatmap ? 'resultCart' : 'result'?>">
                                    0
                                </span>.00 €

                            </h3>

                            <input
                                type="hidden"
                                id="total"
                                name="result"
                                value="0"
                            >

                        </div>

                    </div>


                    <!-- Submit button -->

                    <button
                        type="submit"
                        class="btn btn-dark btn-block mt-4">
                        Order your ticket(s)
                    </button>

                </form>

            </div>

        </div>


        <!-- Subscription script -->

        <?php
        echo '<script src="' .
             _APPDIR .
             'MVCFramework/views/includes/js/subscription.js"></script>';
        ?>


        <!-- SeatChart -->

        <script
            type="text/javascript"
            src="https://cdn.jsdelivr.net/npm/seatchart@0.1.0/dist/seatchart.min.js">
        </script>


        <?php if ($hasSeatmap) {

            echo '<script src="' .
                 _APPDIR .
                 'MVCFramework/views/includes/js/seatmap.js?v=12"></script>';
        } ?>


        <?php if ($hasSeatmap) { ?>

        <script>

            document.addEventListener('DOMContentLoaded', function () {

                const seatmapSection =
                    document.getElementById('seatmapSection');

                const orderSection =
                    document.getElementById('orderSection');

                const reserveSeatsButton =
                    document.getElementById('reserveSeatsButton');

                const changeReservedSeatsButton =
                    document.getElementById('changeReservedSeatsButton');



                /*
                 * Initially:
                 *
                 * Seatmap   = visible
                 * Order form = hidden
                 */

                seatmapSection.style.display = 'block';
                orderSection.style.display = 'none';


                /*
                 * Reserve seats
                 *
                 * Seatmap disappears
                 * Order form appears
                 */

                reserveSeatsButton.addEventListener('click', function () {

                    seatmapSection.style.display = 'none';
                    orderSection.style.display = 'block';

                    /*
                     * Scroll to the order section.
                     * This is particularly useful on mobile/tablet.
                     */

                    orderSection.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });

                });


                /*
                 * Change reserved seats
                 *
                 * Order form disappears
                 * Seatmap appears again
                 */

                changeReservedSeatsButton.addEventListener('click', function () {

                    orderSection.style.display = 'none';
                    seatmapSection.style.display = 'block';

                    /*
                     * Scroll back to the seatmap.
                     */

                    seatmapSection.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });

                });

            });

        </script>

        <?php } ?>

    </body>
</html>