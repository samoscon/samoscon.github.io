<?php
/**
 * ValidateTicketCommand.php
 *
 * @package commands\ajax
 * @version 1.0
 * @copyright (c) 2026, Dirk Van Meirvenne
 * @author Dirk Van Meirvenne
 */
namespace commands\ajax;

/**
 * Validates a ticket presented by the ticket scanner.
 *
 * @author Dirk Van Meirvenne
 */
class ValidateTicketCommand extends \controllerframework\controllers\Command {

    /**
     * Specialization of the execute method of Command.
     *
     * @param \controllerframework\registry\Request $request
     * @return int Status
     */
    #[\Override]
    public function doExecute(
        \controllerframework\registry\Request $request
    ): int {

        $token = $request->get('token');
        $id = (int) $request->get('id');

        if ($id <= 0) {
            $this->addResponses($request, [
                'results' => [[
                    'valid' => false,
                    'message' => 'Geen activiteit geselecteerd'
                ]]
            ]);

            return self::CMD_DEFAULT;
        }
        
        /*
         * Validate token format.
         */
        if (
            !is_string($token) ||
            !preg_match('/^[a-f0-9]{64}$/', $token)
        ) {

            \model\TicketScan::insert([
                'description' => 'Ticket scan',
                'classification' => 'RGLR',
                'scanner' => $this->getScanner(),
                'result' => 'invalid'
            ]);

            $this->addResponses($request, [
                'results' => [[
                    'valid' => false,
                    'message' => 'Ongeldige ticketcode'
                ]]
            ]);

            return self::CMD_DEFAULT;
        }

        /*
         * Find the ticket.
         */
        try {

            $ticket = \model\Ticket::findByToken($token);

        } catch (\Throwable $exc) {

            $request->addFeedback($exc->getMessage());

            return self::CMD_ERROR;
        }

        /*
         * Ticket does not exist.
         */
        if (!$ticket) {

            $this->addResponses($request, [
                'results' => [[
                    'valid' => false,
                    'message' => 'Ticket niet gevonden'
                ]]
            ]);

            return self::CMD_DEFAULT;
        }

        /*
         * Ticket is niet voor de juiste activiteit.
         */
        if ($ticket->subscription->costitem->activity->getId() !== $id) {

            \model\TicketScan::insert([
                'description' => 'Ticket scan',
                'classification' => 'RGLR',
                'ticket_id' => $ticket->getId(),
                'scanner' => $this->getScanner(),
                'result' => 'wrong_activity'
            ]);

            $this->addResponses($request, [
                'results' => [[
                    'valid' => false,
                    'message' => 'Ticket andere activiteit'
                ]]
            ]);

            return self::CMD_DEFAULT;
        }

        /*
         * Ticket has been cancelled.
         */
        if ($ticket->status !== 'valid') {

            \model\TicketScan::insert([
                'description' => 'Ticket scan',
                'classification' => 'RGLR',
                'ticket_id' => $ticket->getId(),
                'scanner' => $this->getScanner(),
                'result' => 'cancelled'
            ]);

            $this->addResponses($request, [
                'results' => [[
                    'valid' => false,
                    'message' => 'Ticket geannuleerd',
                    'ticketId' => $ticket->getId()
                ]]
            ]);

            return self::CMD_DEFAULT;
        }

        /*
         * Atomically claim the ticket.
         *
         * Only one scanner can successfully claim a ticket.
         */
        if (!$ticket->claim()) {

            \model\TicketScan::insert([
                'description' => 'Ticket scan',
                'classification' => 'RGLR',
                'ticket_id' => $ticket->getId(),
                'scanner' => $this->getScanner(),
                'result' => 'already_used'
            ]);

            $this->addResponses($request, [
                'results' => [[
                    'valid' => false,
                    'message' => 'Ticket reeds gebruikt',
                    'ticketId' => $ticket->getId()
                ]]
            ]);

            return self::CMD_DEFAULT;
        }

        /*
         * Ticket successfully claimed.
         */
        \model\TicketScan::insert([
            'description' => 'Ticket scan',
            'classification' => 'RGLR',
            'ticket_id' => $ticket->getId(),
            'scanner' => $this->getScanner(),
            'result' => 'valid'
        ]);

        $this->addResponses($request, [
            'results' => [[
                'valid' => true,
                'message' => 'Ticket geldig',
                'ticketId' => $ticket->getId(),
                'ticketType' => $ticket->classification
            ]]
        ]);

        return self::CMD_DEFAULT;
    }

    /**
     * Returns the name of the currently logged-in scanner.
     *
     * @return string
     */
    private function getScanner(): string
    {
        $user = \controllerframework\sessions\User::getInstance();

        return trim(
            $user->name . ' ' . $user->lastname
        );
    }

    /**
     * Specialization of getLevelOfLoginRequired.
     */
    #[\Override]
    protected function getLevelOfLoginRequired(): void
    {
        $this->setLoginLevel(
            new \controllerframework\sessions\AdminLogin()
        );
    }
}