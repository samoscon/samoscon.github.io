<?php
/**
 * Specialization of a Command
 *
 * Generates a professional PDF with two tickets per A4 page.
 *
 * @package commands\downloads
 * @version 1.0
 * @copyright (c) 2025, Dirk Van Meirvenne
 * @author Dirk Van Meirvenne <van.meirvenne.dirk at gmail.com>
 */

namespace commands\downloads;


/**
 * Specialization of a Command
 *
 * @author Dirk Van Meirvenne <van.meirvenne.dirk at gmail.com>
 */
class DownloadPdfTicketsCommand extends \controllerframework\controllers\Command {

    /**
     * Specialization of the execute method of Command
     *
     * @param \controllerframework\registry\Request $request
     * @return int Status
     */
    #[\Override]
    public function doExecute(\controllerframework\registry\Request $request): int {

        $id = filter_var(
            $request->get('id'),
            FILTER_VALIDATE_INT
        );

        if ($id === false) {
            return self::CMD_DEFAULT;
        }

        /*
         * -------------------------------------------------------------
         * Validate AccessToken
         * -------------------------------------------------------------
         *
         * The token is generated using:
         *
         * AccessToken::generate('mollie-order', $paymentId)
         *
         */

        $token = $request->get('access_token');

        if ($token === '') {
            $request->addFeedback("Wrong ID / token combination");
            return self::CMD_ERROR;
        }

        try {

            \controllerframework\security\AccessToken::validate(
                'mollie-order',
                $id,
                $token
            );

        } catch (\Throwable $ex) {

            \controllerframework\error\ErrorHandler::handleException($ex);

            $request->addFeedback("Wrong ID / token combination");

            return self::CMD_ERROR;
        }

        try {

            /*
             * ---------------------------------------------------------
             * Load payment
             * ---------------------------------------------------------
             */

            $payment = \model\Payment::find($id);

            if ($payment === null) {
                return self::CMD_DEFAULT;
            }

            $title = 'Tickets ' . APP . ' orderid ' . $payment->getId();

            /*
             * ---------------------------------------------------------
             * Collect all tickets
             * ---------------------------------------------------------
             */

            $ticketData = [];

            $subscriptions = \model\Subscription::findAll(
                "WHERE payment_id = " . (int) $payment->getId()
            );

            foreach ($subscriptions as $subscription) {

                $activity = $subscription->costitem->activity;

                /*
                 * -----------------------------------------------------
                 * Seat information
                 * -----------------------------------------------------
                 *
                 * Seat information is stored in subscription->remark.
                 */

                $seatData = [];

//                if (!empty($subscription->remark)) {
                if ($subscription->remark !== null && $subscription->remark) {

                    $remarks = explode(';', $subscription->remark);

                    foreach ($remarks as $remark) {

                        if ($remark === '') {
                            continue;
                        }

                        $seat = json_decode($remark, true);

                        if (
                            is_array($seat)
                            && isset($seat['row'])
                            && isset($seat['col'])
                        ) {

                            $rows = range('A', 'Z');

                            $row = $rows[$seat['row']] ?? '';
                            $col = ((int) $seat['col']) + 1;

                            $seatData[] =
                                'Row: ' . $row . ' · Seat: ' . $col;

                        } else {

                            $seatData[] = '';
                        }
                    }
                }

                /*
                 * -----------------------------------------------------
                 * Get actual Ticket objects
                 * -----------------------------------------------------
                 */

                $tickets = \model\Ticket::findAll(
                    "WHERE subscription_id = " .
                    (int) $subscription->getId()
                );

                $ticketNumber = 1;

                foreach ($tickets as $ticket) {

                    $seatDescription =
                        $seatData[$ticketNumber - 1] ?? '';

                    $ticketData[] = [
                        'ticket'        => $ticket,
                        'subscription'  => $subscription,
                        'activity'      => $activity,
                        'member'        => $subscription->member,
                        'ticket_number' => $ticketNumber,
                        'seat'          => $seatDescription,
                    ];

                    $ticketNumber++;
                }
            }

            /*
             * ---------------------------------------------------------
             * Create PDF
             * ---------------------------------------------------------
             */

            $pdf = new PDF('P', 'mm', 'A4');

            $pdf->SetTitle($title, true);
            $pdf->AliasNbPages();

            $totalTickets = count($ticketData);

            for ($i = 0; $i < $totalTickets; $i++) {

                /*
                 * Every two tickets use one A4 page.
                 */

                if ($i % 2 === 0) {
                    $pdf->AddPage();
                }

                /*
                 * 0 = upper ticket
                 * 1 = lower ticket
                 */

                $ticketPosition =
                    ($i % 2 === 0) ? 0 : 1;

                $pdf->DrawTicket(
                    $ticketData[$i],
                    $ticketPosition,
                    $i + 1,
                    $totalTickets,
                    $payment->getId()
                );
            }

            /*
             * ---------------------------------------------------------
             * Output
             * ---------------------------------------------------------
             */

            $pdf->Output(
                'D',
                $title . '.pdf'
            );

        } catch (\Throwable $exc) {

            \controllerframework\error\ErrorHandler::handleException(
                $exc
            );
        }

        return self::CMD_DEFAULT;
    }


    /**
     * Specialization of getLevelOfLoginRequired
     */
    #[\Override]
    protected function getLevelOfLoginRequired(): void {

        $this->setLoginLevel(
            new \controllerframework\sessions\NoLoginRequired()
        );
    }
}


/**
 * PDF class used for the ticket layout.
 */
class PDF extends \FPDF {

    /**
     * Width of an A4 page in mm.
     */
    private const PAGE_WIDTH = 210;

    /**
     * Height of an A4 page in mm.
     */
    private const PAGE_HEIGHT = 297;

    /**
     * Page margin.
     */
    private const MARGIN = 10;

    /**
     * Height of one ticket.
     */
    private const TICKET_HEIGHT = 128;

    /**
     * Gap between the two tickets.
     */
    private const TICKET_GAP = 10;


    /**
     * Draw one ticket.
     *
     * @param array $data
     * @param int $position 0 = upper ticket, 1 = lower ticket
     * @param int $ticketNumber
     * @param int $totalTickets
     * @param int $orderId
     */
    public function DrawTicket(
        array $data,
        int $position,
        int $ticketNumber,
        int $totalTickets,
        int $orderId
    ): void {

        $ticket = $data['ticket'];
        $subscription = $data['subscription'];
        $activity = $data['activity'];
        $member = $data['member'];
        $seat = $data['seat'];

        /*
         * -------------------------------------------------------------
         * Calculate ticket position
         * -------------------------------------------------------------
         *
         * IMPORTANT:
         * The gap is included here.
         *
         * Ticket 1: y = 10
         * Ticket 2: y = 148
         */

        $x = self::MARGIN;

        $y = self::MARGIN
            + (
                $position *
                (self::TICKET_HEIGHT + self::TICKET_GAP)
            );

        $width =
            self::PAGE_WIDTH - (2 * self::MARGIN);

        $height =
            self::TICKET_HEIGHT - 4;


        /*
         * -------------------------------------------------------------
         * Ticket border
         * -------------------------------------------------------------
         */

        $this->SetDrawColor(160, 160, 160);
        $this->SetLineWidth(0.4);

        $this->Rect(
            $x,
            $y,
            $width,
            $height
        );


        /*
         * -------------------------------------------------------------
         * Logo
         * -------------------------------------------------------------
         */

        if (
            defined('_LOGO')
            && file_exists(_LOGO)
        ) {

            $this->Image(
                _LOGO,
                $x + 5,
                $y + 5,
                28
            );
        }


        /*
         * -------------------------------------------------------------
         * Activity title
         * -------------------------------------------------------------
         */

        $this->SetTextColor(155, 75, 125);

        $this->SetFont(
            'Arial',
            'B',
            18
        );

        /*
         * Title is placed to the right of the logo.
         */

        $this->SetXY(
            $x + 38,
            $y + 10
        );

        $this->Cell(
            $width - 43,
            8,
            $this->safeText(
                $activity->description
            ),
            0,
            1,
            'L'
        );


        /*
         * -------------------------------------------------------------
         * Date and time
         * -------------------------------------------------------------
         */

        $date = '';

        if ($activity->date !== null && $activity->date !== '') {
            $date = date(
                'd/m/Y',
                strtotime($activity->date)
            );
        }

        $time = '';

        if ($activity->start !== null && $activity->start !== '') {
            $time .= substr($activity->start, 0, 5);
        }

        if ($activity->end !== null && $activity->end !== '') {
            $time .= ' - ' . substr($activity->end, 0, 5);
        }


        $dateTime = $date;

        if ($time !== '') {

            if ($dateTime !== '') {
                $dateTime .= ' · ';
            }

            $dateTime .= $time;
        }

        $this->SetFont(
            'Arial',
            'B',
            9
        );

        $this->SetXY(
            $x + 38,
            $y + 20
        );

        $this->Cell(
            $width - 43,
            5,
            $this->safeText($dateTime),
            0,
            1,
            'L'
        );


        /*
         * -------------------------------------------------------------
         * Location
         * -------------------------------------------------------------
         */

        if (!$activity->isComposite()) {

            $this->SetFont(
                'Arial',
                '',
                8
            );

            $this->SetXY(
                $x + 38,
                $y + 27
            );

            $this->MultiCell(
                $width - 43,
                4,
                $this->safeText(
                    $activity->location
                ),
                0,
                'L'
            );

        } else {

            /*
             * For composite activities, use the long description.
             */

            $this->SetFont(
                'Arial',
                '',
                8
            );

            $this->SetXY(
                $x + 38,
                $y + 27
            );

            $this->MultiCell(
                $width - 43,
                4,
                $this->safeText(
                    str_replace(
                        '&nbsp;',
                        '',
                        strip_tags(
                            $activity->longdescription
                        )
                    )
                ),
                0,
                'L'
            );
        }


        /*
         * -------------------------------------------------------------
         * Separator
         * -------------------------------------------------------------
         */

        $this->SetDrawColor(
            200,
            200,
            200
        );

        $this->SetLineWidth(0.2);

        $this->Line(
            $x + 5,
            $y + 39,
            $x + $width - 5,
            $y + 39
        );


        /*
         * -------------------------------------------------------------
         * Ticket number
         * -------------------------------------------------------------
         */

        $this->SetTextColor(0, 0, 0);

        $this->SetFont(
            'Arial',
            'B',
            10
        );

        $this->SetXY(
            $x + 5,
            $y + 44
        );

        $this->Cell(
            45,
            5,
            'TICKET ' . $ticketNumber,
            0,
            0,
            'L'
        );


        /*
         * -------------------------------------------------------------
         * Cost item description
         * -------------------------------------------------------------
         */

        $ticketDescription =
            $subscription->costitem->description;

        $this->SetFont(
            'Arial',
            'B',
            9
        );

        $this->SetXY(
            $x + 45,
            $y + 43
        );

        $this->Cell(
            $width - 90,
            5,
            $this->safeText($ticketDescription),
            0,
            0,
            'L'
        );


        /*
         * -------------------------------------------------------------
         * Price
         * -------------------------------------------------------------
         */

        $price = '';

        if ($subscription->costitem->price !== null
            && $subscription->costitem->price !== '') {

            $price = number_format(
                (float) $subscription->costitem->price,
                2,
                ',',
                '.'
            ) . ' EUR';
        }

        $this->SetFont(
            'Arial',
            'B',
            9
        );

        $this->SetXY(
            $x + $width - 45,
            $y + 43
        );

        $this->Cell(
            40,
            5,
            $this->safeText($price),
            0,
            0,
            'R'
        );

        /*
         * -------------------------------------------------------------
         * Ordered by
         * -------------------------------------------------------------
         */

        $this->SetTextColor(0, 0, 0);

        $this->SetFont(
            'Arial',
            'B',
            8
        );

        $this->SetXY(
            $x + 5,
            $y + 53
        );

        $this->Cell(
            50,
            4,
            'ORDERED BY',
            0,
            1,
            'L'
        );


        /*
         * Customer name
         */

        $memberName = $member->name;
//            trim(
//                $member->name .
//                ' ' .
//                $member->lastname
//            );

        $this->SetTextColor(150, 110, 70);

        $this->SetFont(
            'Arial',
            '',
            9
        );

        $this->SetXY(
            $x + 5,
            $y + 58
        );

        $this->Cell(
            100,
            5,
            $this->safeText($memberName),
            0,
            1,
            'L'
        );


        /*
         * Customer email
         */

        $this->SetFont(
            'Arial',
            '',
            8
        );

        $this->SetTextColor(
            90,
            90,
            90
        );

        $this->SetXY(
            $x + 5,
            $y + 64
        );

        $this->Cell(
            100,
            4,
            $this->safeText(
                $member->email
            ),
            0,
            1,
            'L'
        );


        /*
         * -------------------------------------------------------------
         * Seat
         * -------------------------------------------------------------
         */

        if ($seat !== '') {

            $this->SetTextColor(
                0,
                120,
                130
            );

            $this->SetFont(
                'Arial',
                'B',
                9
            );

            $this->SetXY(
                $x + 5,
                $y + 72
            );

            $this->Cell(
                100,
                5,
                $this->safeText($seat),
                0,
                1,
                'L'
            );
        }


        /*
         * -------------------------------------------------------------
         * QR code
         * -------------------------------------------------------------
         */

        $qrFile =
            sys_get_temp_dir()
            . '/ticket_qr_'
            . bin2hex(
                random_bytes(8)
            )
            . '.png';

        $qrSize = 46;

        $qrX =
            $x
            + $width
            - $qrSize
            - 8;

        $qrY =
            $y + 48;

        try {

            $options =
                new \chillerlan\QRCode\QROptions();

            $options->outputType =
                \chillerlan\QRCode\Output\QROutputInterface::GDIMAGE_PNG;

            $options->scale = 5;

            /*
             * The ticket token is the QR-code content.
             */

            (new \chillerlan\QRCode\QRCode($options))
                ->render(
                    $ticket->token,
                    $qrFile
                );


            $this->Image(
                $qrFile,
                $qrX,
                $qrY,
                $qrSize,
                $qrSize,
                'PNG'
            );

        } finally {

            if (file_exists($qrFile)) {
                unlink($qrFile);
            }
        }


        /*
         * -------------------------------------------------------------
         * QR instruction
         * -------------------------------------------------------------
         */

        $this->SetTextColor(
            80,
            80,
            80
        );

        $this->SetFont(
            'Arial',
            '',
            7
        );

        $this->SetXY(
            $qrX - 2,
            $qrY + $qrSize + 2
        );

        $this->Cell(
            $qrSize + 4,
            4,
            'Scan this QR code at the entrance',
            0,
            1,
            'C'
        );


        /*
         * -------------------------------------------------------------
         * Footer
         * -------------------------------------------------------------
         */

        $this->SetTextColor(
            100,
            100,
            100
        );

        $this->SetFont(
            'Arial',
            '',
            7
        );

        $this->SetXY(
            $x + 5,
            $y + $height - 10
        );

        $this->Cell(
            $width - 50,
            4,
            'Order #' . $orderId,
            0,
            0,
            'L'
        );

        $this->Cell(
            45,
            4,
            'Ticket ' .
            $ticketNumber .
            ' / ' .
            $totalTickets,
            0,
            0,
            'R'
        );


        /*
         * -------------------------------------------------------------
         * Cutting line between the two tickets
         * -------------------------------------------------------------
         *
         * The line is drawn in the actual gap between the tickets.
         */

        if (
            $position === 0
            && $ticketNumber < $totalTickets
        ) {

            $this->drawCuttingLine();
        }
    }


    /**
     * Draw the cutting line between the two tickets.
     *
     * FPDF does not provide SetDash() in all versions,
     * therefore the dashed line is drawn manually.
     */
    private function drawCuttingLine(): void {

        $cutY =
            self::MARGIN
            + self::TICKET_HEIGHT
            + (self::TICKET_GAP / 2);

        $this->SetDrawColor(
            170,
            170,
            170
        );

        $this->SetLineWidth(0.2);

        $startX = 10;
        $endX =
            self::PAGE_WIDTH - 10;

        $dashLength = 3;
        $gapLength = 2;

        for (
            $x = $startX;
            $x < $endX;
            $x += ($dashLength + $gapLength)
        ) {

            $this->Line(
                $x,
                $cutY,
                min(
                    $x + $dashLength,
                    $endX
                ),
                $cutY
            );
        }
    }


    /**
     * Escape text for FPDF standard fonts.
     *
     * FPDF standard fonts use Windows-1252.
     *
     * @param string|null $text
     * @return string
     */
    private function safeText(
        ?string $text
    ): string {

        if ($text === null) {
            return '';
        }

        return iconv(
            'UTF-8',
            'Windows-1252//TRANSLIT',
            $text
        );
    }


    /**
     * Disable the normal page header.
     *
     * The complete ticket header is drawn by DrawTicket().
     */
    public function Header(): void {
        // Ticket header is drawn by DrawTicket().
    }


    /**
     * Disable the normal page footer.
     *
     * Ticket footer is drawn by DrawTicket().
     */
    public function Footer(): void {
        // Ticket footer is drawn by DrawTicket().
    }
}