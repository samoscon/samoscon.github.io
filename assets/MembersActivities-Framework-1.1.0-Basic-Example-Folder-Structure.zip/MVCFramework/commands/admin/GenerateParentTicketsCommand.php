<?php
/**
 * GenerateParentTicketsCommand.php
 *
 * @package commands\admin
 * @version 1.0
 * @copyright (c) 2026, Dirk Van Meirvenne
 * @author Dirk Van Meirvenne
 */
namespace commands\admin;


/**
 * Specialization of a Command
 *
 * @author Dirk Van Meirvenne <van.meirvenne.dirk at gmail.com>
 */

class GenerateParentTicketsCommand extends \controllerframework\controllers\Command {

    #[\Override]
    public function doExecute(
        \controllerframework\registry\Request $request
    ): int {

        $id = filter_var($request->get('id'), FILTER_VALIDATE_INT);
        if(!$id) {
            $request->set('errorcode', 'wrongID');
            $request->addFeedback("Wrong ID");
            return self::CMD_ERROR;
        }
        
        try {
            $activity = \model\Activity::find($id);
            if($activity->isComposite()) {
                $request->addFeedback("This activity is a composite. We can not generate tickets for a composite.");
                return self::CMD_ERROR;
            }
        } 
        catch (\Throwable $ex) {
            \controllerframework\error\ErrorHandler::handleException($ex);
            $request->addFeedback('Unable to retrieve the requested item.');
            return self::CMD_ERROR;
        }
        
        $participants = $activity->parent->getParticipants();
        
        $costitems = \model\Costitem::findAll(
            'WHERE activity_id = ' . $activity->getId()
        );
        $costitem = $costitems->current() ?? null;
        

        /** Check that the page was requested from itself via the POST method. */
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            /** Validate CSRF token before processing. */ 
            if (!$this->validateCsrfToken($request)) { 
                $request->set('errorcode', 'InvalidCsrfToken');
                return self::CMD_ERROR;
            }
            
            foreach ($participants as $participant) {
                $payment = \model\Payment::insert([
                    'member_id' => $participant->getId(),
                    'status' => 'open',
                    'type' => 'free',
                    'source' => 'web'
                ]);
                \model\Subscription::insert([
                    'member_id' => $participant->getId(),
                    'costitem_id' => $costitem->getId(),
                    'payment_id' => $payment->getId(),
                    'quantity' => str_contains($participant->costitem, '2 ticket') ? 2 : 1,
                    'remark' => ''
                ]);
                $payment->statusReceived('paid');
            }
            $request->set('forwardqueryparams', ['id' => $id]);
            return self::CMD_OK;
        }
            
        $this->addResponses($request, [
            'csrf_token' => $this->getCsrfToken(),
            'activity' => $activity,
            'participants' => $participants,
            'returnpath' => '/editActivity?id='. $activity->getId()
        ]);

        return self::CMD_DEFAULT;
    }

    #[\Override]
    protected function getLevelOfLoginRequired(): void
    {
        $this->setLoginLevel(
            new \controllerframework\sessions\AdminLogin()
        );
    }
}