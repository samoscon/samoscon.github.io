<?php
/**
 * TicketScannerCommand.php
 *
 * @package commands\admin
 * @version 1.0
 * @copyright (c) 2026, Dirk Van Meirvenne
 * @author Dirk Van Meirvenne
 */
namespace commands\admin;

use controllerframework\security\AccessToken;

/**
 * Specialization of a Command
 *
 * @author Dirk Van Meirvenne <van.meirvenne.dirk at gmail.com>
 */

class TicketScannerCommand extends \controllerframework\controllers\Command {

    #[\Override]
    public function doExecute(
        \controllerframework\registry\Request $request
    ): int {

        $user = \controllerframework\sessions\User::getInstance();

        $id = filter_var($request->get('id'), FILTER_VALIDATE_INT);
        if(!$id) {
//            $request->set('errorcode', 'wrongID');
//            $request->addFeedback("Wrong ID");
            return self::CMD_CONTINUE;
        }
        
        $token = ($request->get('token'));

        if (
            $token === '' ||
            !AccessToken::validate(
                'ticket_scan',
                $id,
                $token
            )
        ) {
            $request->addFeedback("Wrong ID / token combination");
            return self::CMD_ERROR;
        }
        
        try {
            $activity = \model\Activity::find($id);
            $activity->date = date('d/m/Y', strtotime($activity->date));
            $activity->duedate = date('d/m/Y', strtotime($activity->duedate));
            $activity->start = $activity->start ? substr($activity->start,0,5) : '';
            $activity->end = substr($activity->end ?? '',0,5);     
        } 
        catch (\Throwable $ex) {
            \controllerframework\error\ErrorHandler::handleException($ex);
            $request->addFeedback('Unable to retrieve the requested item.');
            return self::CMD_ERROR;
        }

        if($activity->isComposite()) {
            $request->addFeedback('Unable to handle the requested item. It is a composite');
            return self::CMD_ERROR;
        }
            
        $this->addResponses($request, [
            'activity' => $activity,
            'user' => $user
        ]);

        return self::CMD_DEFAULT;
    }

    #[\Override]
    protected function getLevelOfLoginRequired(): void
    {
        $this->setLoginLevel(
            new \controllerframework\sessions\AdminLogin()
        );
    }
}