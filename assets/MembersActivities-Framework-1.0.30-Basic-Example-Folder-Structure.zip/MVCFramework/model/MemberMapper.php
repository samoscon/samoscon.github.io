<?php
/**
 * MemberMapper.php
 *
 * @package members
 * @version 1.0
 * @copyright (c) 2025, Dirk Van Meirvenne
 * @author Dirk Van Meirvenne <van.meirvenne.dirk at gmail.com>
 */
namespace model;

/**
 * Specific implementation for the abstract class MemberMapper for the MMC application
 *
 * @link ../graphs/members%20Class%20Diagram.svg Members class diagram
 * @author Dirk Van Meirvenne <van.meirvenne.dirk at gmail.com>
 */
final class MemberMapper extends \controllerframework\members\MemberMapper {
//    put your code here
}
