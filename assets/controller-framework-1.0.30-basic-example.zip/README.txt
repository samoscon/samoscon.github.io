Basic Controller Framework 1.0.30 example

1. Create the database and execute DatabaseSetup.sql.
2. Edit config/app_options.ini with your database and HTTPS application URL.
3. Install dependencies:
       composer install
4. Ensure the application is served over HTTPS.
5. Open the application root.
6. Log in with:
       demo@example.com
       Demo123!
7. The protected /welcome screen displays the user's name.
8. Click Logout to return to the login screen.

This is an educational/minimal example, not a production-ready application.
In production:
- use environment=production;
- do not enable display_errors;
- use a real mail configuration;
- review server permissions and HTTPS configuration;
- use a strong unique demo/test password and remove test credentials.
