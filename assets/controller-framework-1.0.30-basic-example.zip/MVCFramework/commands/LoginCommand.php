<?php

namespace commands;

use controllerframework\controllers\Command;
use controllerframework\registry\Request;
use controllerframework\sessions\NoLoginRequired;

final class LoginCommand extends Command
{
    public function doExecute(Request $request): int
    {
        // LoginManager starts the session and makes CSRF available.
        $this->reg->getLoginManager();

        $passwordIsValid = true;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!$this->validateCsrfToken($request)) {
                $request->set('errorcode', 'InvalidCsrfToken');
                return self::CMD_ERROR;
            }

            $username = trim((string) $request->get('username'));
            $password = (string) $request->get('password');

            $memberId = $this->reg->getLoginManager()
                ->validateUsername($username);

            if ($memberId !== false) {
                $passwordIsValid = $this->reg->getLoginManager()
                    ->validatePassword((int) $memberId, $password);
            } else {
                $passwordIsValid = false;
            }

            if ($passwordIsValid) {
                $keepLoggedIn = $request->get('rememberMe') === 'Y';

                $this->reg->getLoginManager()->login(
                    (int) $memberId,
                    $keepLoggedIn
                );

                return self::CMD_OK;
            }
        }

        $request->set('csrf_token', $this->getCsrfToken());
        $request->set('passwordIsValid', $passwordIsValid);

        return self::CMD_DEFAULT;
    }

    protected function getLevelOfLoginRequired(): void
    {
        $this->setLoginLevel(new NoLoginRequired());
    }
}
