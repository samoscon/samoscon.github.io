<?php

namespace commands;

use controllerframework\controllers\Command;
use controllerframework\registry\Request;
use controllerframework\sessions\User;
use controllerframework\sessions\UserLogin;

final class WelcomeCommand extends Command
{
    public function doExecute(Request $request): int
    {
        $user = User::getInstance();

        if ($user === null) {
            return self::CMD_ERROR;
        }

        $request->set('name', (string) $user->name);

        return self::CMD_OK;
    }

    protected function getLevelOfLoginRequired(): void
    {
        $this->setLoginLevel(new UserLogin());
    }
}
