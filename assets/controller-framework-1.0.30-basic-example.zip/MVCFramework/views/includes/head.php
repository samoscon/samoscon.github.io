<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
    body {
        font-family: system-ui, sans-serif;
        max-width: 760px;
        margin: 0 auto;
        padding: 3rem 1.5rem;
        line-height: 1.5;
    }
    form {
        max-width: 420px;
    }
    label {
        display: block;
        margin-top: 1rem;
        font-weight: 600;
    }
    input {
        width: 100%;
        box-sizing: border-box;
        padding: .7rem;
        margin-top: .35rem;
    }
    button {
        margin-top: 1.2rem;
        padding: .7rem 1.2rem;
        cursor: pointer;
    }
    .error {
        color: #b91c1c;
        margin-top: 1rem;
    }
    .card {
        padding: 2rem;
        border: 1px solid #ddd;
        border-radius: 10px;
    }
</style>
