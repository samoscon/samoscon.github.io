<!DOCTYPE html>
<html lang="en">
<head>
    <?php include __DIR__ . '/includes/head.php'; ?>
    <title>Welcome</title>
</head>
<body>
<div class="card">
    <h1>
        Hi <?= htmlspecialchars(
            (string) $request->get('name'),
            ENT_QUOTES,
            'UTF-8'
        ) ?>, welcome to our login protected environment.
    </h1>

    <form method="get" action="/logout">
        <button type="submit">Logout</button>
    </form>
</div>
</body>
</html>
