<!DOCTYPE html>
<html lang="en">
<head>
    <?php include __DIR__ . '/includes/head.php'; ?>
    <title>Login</title>
</head>
<body>
<div class="card">
    <h1>Login</h1>

    <?php if (!$request->get('passwordIsValid')): ?>
        <p class="error">The username/password combination is not correct.</p>
    <?php endif; ?>

    <form method="post" action="/">
        <input
            type="hidden"
            name="csrf_token"
            value="<?= htmlspecialchars(
                (string) $request->get('csrf_token'),
                ENT_QUOTES,
                'UTF-8'
            ) ?>"
        >

        <label for="username">Email address</label>
        <input
            type="email"
            id="username"
            name="username"
            autocomplete="username"
            required
        >

        <label for="password">Password</label>
        <input
            type="password"
            id="password"
            name="password"
            autocomplete="current-password"
            required
        >

        <label>
            <input type="checkbox" name="rememberMe" value="Y">
            Remember me
        </label>

        <button type="submit">Log in</button>
    </form>
</div>
</body>
</html>
