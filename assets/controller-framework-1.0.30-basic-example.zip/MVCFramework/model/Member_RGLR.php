<?php

namespace model;

final class Member_RGLR extends \controllerframework\members\MemberTypeImplementation
{
    public function getYearlyParticipationFee(Member $member): int
    {
        return 0;
    }
}
