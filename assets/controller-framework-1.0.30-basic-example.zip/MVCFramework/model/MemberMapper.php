<?php

namespace model;

final class MemberMapper extends \controllerframework\members\MemberMapper
{
}
