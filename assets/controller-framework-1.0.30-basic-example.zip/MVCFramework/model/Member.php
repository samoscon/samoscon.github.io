<?php

namespace model;

class Member extends \controllerframework\members\Member
{
    public function initiatePassword(string $pwd = ''): string
    {
        return 'Your temporary password is ' . htmlspecialchars(
            $pwd,
            ENT_QUOTES,
            'UTF-8'
        );
    }
}
