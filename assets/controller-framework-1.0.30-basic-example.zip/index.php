<?php

require __DIR__ . '/vendor/autoload.php';

/*
 * Client application autoloader.
 *
 * Classes in the MVCFramework directory are mapped directly
 * from their PHP namespace to their file path.
 */
spl_autoload_register(function (string $className): void {
    $file = __DIR__
        . '/MVCFramework/'
        . str_replace('\\', '/', $className)
        . '.php';

    if (is_file($file)) {
        require_once $file;
    }
});

controllerframework\controllers\Controller::run();
