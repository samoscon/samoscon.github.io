CREATE TABLE member (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    description VARCHAR(190) DEFAULT 'description',
    classification VARCHAR(4) NOT NULL DEFAULT 'RGLR',
    parent_id INT UNSIGNED DEFAULT 0,
    name VARCHAR(45) DEFAULT 'name',
    lastname VARCHAR(45) DEFAULT 'lastname',
    email VARCHAR(255) DEFAULT NULL,
    role VARCHAR(5) NOT NULL DEFAULT 'U',
    password VARCHAR(256) DEFAULT NULL,
    ownpwd TINYINT(1) DEFAULT 0,
    active TINYINT(1) DEFAULT 0,
    subscriptionuntil DATE DEFAULT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_member_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE remember_tokens (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    member_id INT UNSIGNED NOT NULL,
    selector CHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    token_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_used_at DATETIME NULL DEFAULT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_remember_selector (selector),
    KEY idx_remember_member (member_id),
    KEY idx_remember_expires (expires_at),
    CONSTRAINT fk_remember_member
        FOREIGN KEY (member_id) REFERENCES member(id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Demo user:
-- email: demo@example.com
-- password: Demo123!
INSERT INTO member
    (classification, name, lastname, email, role, password, ownpwd, active)
VALUES
    (
        'RGLR',
        'Demo User',
        'Example',
        'demo@example.com',
        'U',
        '$2y$12$CM39.EaqzfUqdivsgnL8bu2Kyz1jMasOI9A8xWMoujgAYk94lvLTu',
        1,
        1
    );
